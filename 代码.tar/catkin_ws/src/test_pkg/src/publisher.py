import rospy
from nav_msgs.msg import Odometry
from sensor_msgs.msg import Imu, LaserScan, MagneticField

def talker():
    rospy.init_node('sensor_data_talker', anonymous=True)


    pub_encoder = rospy.Publisher('/driver/encoder', Odometry, queue_size=10)
    pub_imu = rospy.Publisher('/driver/imu', Imu, queue_size=10)
    pub_laser_scan = rospy.Publisher('/driver/scan', LaserScan, queue_size=10)
    pub_magnetic_field = rospy.Publisher('/driver/mag', MagneticField, queue_size=10)

    rate = rospy.Rate(10)  # 10Hz

    while not rospy.is_shutdown():

        odom = Odometry()
        odom.pose.pose.position.x = 1.0
        odom.pose.pose.position.y = 2.0
        pub_encoder.publish(odom)


        imu = Imu()
        imu.linear_acceleration.x = 0.0
        imu.linear_acceleration.y = 9.81
        imu.linear_acceleration.z = 0.0
        pub_imu.publish(imu)


        laser_scan = LaserScan()
        laser_scan.angle_min = 0.0
        laser_scan.angle_max = 1.57
        pub_laser_scan.publish(laser_scan)


        magnetic_field = MagneticField()
        magnetic_field.magnetic_field.x = 0.1
        magnetic_field.magnetic_field.y = 0.2
        magnetic_field.magnetic_field.z = 0.3
        pub_magnetic_field.publish(magnetic_field)

        rate.sleep()

if __name__ == '__main__':
    try:
        talker()
    except rospy.ROSInterruptException:
        pass

