#include <ros/ros.h>
#include <nav_msgs/Odometry.h>
#include <sensor_msgs/Imu.h>
#include <sensor_msgs/LaserScan.h>
#include <sensor_msgs/MagneticField.h>


void encoderCallback(const nav_msgs::Odometry::ConstPtr& msg)
{
    ROS_INFO("Odometry: x = %f, y = %f, z = %f", msg->pose.pose.position.x, msg->pose.pose.position.y, msg->pose.pose.position.z);
}

void imuCallback(const sensor_msgs::Imu::ConstPtr& msg)
{
    ROS_INFO("IMU: linear_accel = [x: %f, y: %f, z: %f]", msg->linear_acceleration.x, msg->linear_acceleration.y, msg->linear_acceleration.z);
}

void laserScanCallback(const sensor_msgs::LaserScan::ConstPtr& msg)
{
    ROS_INFO("LaserScan: angle_min = %f, angle_max = %f", msg->angle_min, msg->angle_max);
}

void magneticFieldCallback(const sensor_msgs::MagneticField::ConstPtr& msg)
{
    ROS_INFO("MagneticField: magnetic_field = [x: %f, y: %f, z: %f]", msg->magnetic_field.x, msg->magnetic_field.y, msg->magnetic_field.z);
}

int main(int argc, char** argv)
{
    ros::init(argc, argv, "sensor_data_subscriber");
    ros::NodeHandle nh;


    ros::Subscriber subEncoder = nh.subscribe("/driver/encoder", 1000, encoderCallback);
    ros::Subscriber subImu = nh.subscribe("/driver/imu", 1000, imuCallback);
    ros::Subscriber subLaserScan = nh.subscribe("/driver/scan", 1000, laserScanCallback);
    ros::Subscriber subMagneticField = nh.subscribe("/driver/mag", 1000, magneticFieldCallback);


    ros::spin();

    return 0;
}

