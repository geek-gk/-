#include <ros/ros.h>
#include <nav_msgs/Odometry.h>
#include <sensor_msgs/Imu.h>
#include <sensor_msgs/LaserScan.h>
#include <sensor_msgs/MagneticField.h>

int main(int argc, char** argv)
{
    ros::init(argc, argv, "sensor_data_publisher");
    ros::NodeHandle nh;


    ros::Publisher pubEncoder = nh.advertise<nav_msgs::Odometry>("/driver/encoder", 1000);
    ros::Publisher pubImu = nh.advertise<sensor_msgs::Imu>("/driver/imu", 1000);
    ros::Publisher pubLaserScan = nh.advertise<sensor_msgs::LaserScan>("/driver/scan", 1000);
    ros::Publisher pubMagneticField = nh.advertise<sensor_msgs::MagneticField>("/driver/mag", 1000);

    ros::Rate loop_rate(10);  

    while (ros::ok())
    {

        nav_msgs::Odometry odom;
        odom.pose.pose.position.x = 1.0;
        odom.pose.pose.position.y = 2.0;
        pubEncoder.publish(odom);


        sensor_msgs::Imu imu;
        imu.linear_acceleration.x = 0.0;
        imu.linear_acceleration.y = 9.81;
        imu.linear_acceleration.z = 0.0;
        pubImu.publish(imu);


        sensor_msgs::LaserScan laserScan;
        laserScan.angle_min = 0.0;
        laserScan.angle_max = 1.57;
        pubLaserScan.publish(laserScan);

 
        sensor_msgs::MagneticField magneticField;
        magneticField.magnetic_field.x = 0.1;
        magneticField.magnetic_field.y = 0.2;
        magneticField.magnetic_field.z = 0.3;
        pubMagneticField.publish(magneticField);

        ros::spinOnce();
        loop_rate.sleep();
    }

    return 0;
}

