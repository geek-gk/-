import rospy
from nav_msgs.msg import Odometry
from sensor_msgs.msg import Imu, LaserScan, MagneticField


def encoder_callback(msg):
    rospy.loginfo("Odometry: x = %f, y = %f, z = %f", msg.pose.pose.position.x, msg.pose.pose.position.y, msg.pose.pose.position.z)

def imu_callback(msg):
    rospy.loginfo("IMU: linear_accel = [x: %f, y: %f, z: %f]", msg.linear_acceleration.x, msg.linear_acceleration.y, msg.linear_acceleration.z)

def laser_scan_callback(msg):
    rospy.loginfo("LaserScan: angle_min = %f, angle_max = %f", msg.angle_min, msg.angle_max)

def magnetic_field_callback(msg):
    rospy.loginfo("MagneticField: magnetic_field = [x: %f, y: %f, z: %f]", msg.magnetic_field.x, msg.magnetic_field.y, msg.magnetic_field.z)

def listener():
    rospy.init_node('sensor_data_listener', anonymous=True)


    rospy.Subscriber("/driver/encoder", Odometry, encoder_callback)
    rospy.Subscriber("/driver/imu", Imu, imu_callback)
    rospy.Subscriber("/driver/scan", LaserScan, laser_scan_callback)
    rospy.Subscriber("/driver/mag", MagneticField, magnetic_field_callback)

    rospy.spin()

if __name__ == '__main__':
    listener()

